package basicmod.util;

import static basicmod.BasicMod.audioPath;

public class Sounds {
    public static String TEST_SOUND = audioPath("test.wav"); //Load audio using a given path
    public static String ding; //Load audio from audioPath based on the field name
}
